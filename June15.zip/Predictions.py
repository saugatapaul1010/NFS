import smtplib
import pandas as pd
from tensorflow.keras.models import load_model
import numpy as np
from datetime import timedelta
import requests
import argparse

root_path = "/home/neo/Desktop/Latest/Deploy_15th_June/"
gmail_user = 'saugata.paul1010@gmail.com'
gmail_password = 'rwcgprqklvaglvfj'
to_ = ['rimo.2k8@gmail.com']

# baseurl ="http://35.193.204.110:9200"
# url = baseurl+'/metricbeat-nfs-server/_pit?keep_alive=5m'     #Different
# myobj = {}
# x = requests.post(url, data = myobj)
# pit_id = x.json()["id"]

cpu_list = []
disk_list = []
sort_id = ""


def _getdata(pit_id,_type, sort_id=None):
    timestamps = []

    while len(timestamps) < 1461:
        searchurl = baseurl+"/_search"
        if(_type == 'cpu'):
            data = {
              "size": 1500,
              "query": {
                "bool": { 
                  "filter": [ 
                    { 
                      "range": { 
                        "@timestamp": { 
                          "gte": "now-2y" 
                        } 
                      } 
                    } 
                  ],
                    "must":{
                        "exists": {
                          "field": "system.cpu.system.pct"
                        }
    
                    }
                }
              },
              "pit": {
                    "id":  pit_id, 
                    "keep_alive": "5m"
              },
              "sort": [ 
                {"@timestamp": "asc"}
              ]
            }
            
        elif(_type == 'disk'):
            data = {
              "size": 1500,
              "query": {
                "bool": { 
                  "filter": [ 
                    { 
                      "range": { 
                        "@timestamp": { 
                          "gte": "now-2y" 
                        } 
                      } 
                    } 
                  ],
                    "must":{
                        "exists": {
                          "field": "system.memory.actual.used.pct"
                        }
    
                    }
                }
              },
              "pit": {
                    "id":  pit_id, 
                    "keep_alive": "5m"
              },
              "sort": [ 
                {"@timestamp": "asc"}
              ]
            }

        if sort_id!=None:
            data["search_after"] = [sort_id]
            data["track_total_hits"]=False

        headers = {'Content-Type': 'application/json'}
        x = requests.post(searchurl, json = data, headers=headers)
        response = x.json()
        pit_id = response["pit_id"]

        for hit in response['hits']['hits']:
            timestamps.append(hit['_source']["@timestamp"])
            if(_type == 'cpu'):
                cpu_list.append(hit['_source']['system']["cpu"]['system']['pct'])
            elif(_type == 'disk'):
                disk_list.append(hit['_source']['system']["memory"]['actual']['used']['pct'])

            sort_id = hit["sort"][0]

    if(_type == 'cpu'):
        data_f =  pd.DataFrame({"timestamp":pd.to_datetime(timestamps),"cpu":cpu_list}, columns = ['timestamp', 'cpu'])
    elif(_type == 'disk'):
        data_f = pd.DataFrame({"timestamp":pd.to_datetime(timestamps),"disk":disk_list}, columns = ['timestamp', 'disk'])

    return data_f

#For manual data loading
def load_data(params):
    df = pd.read_csv(params['df_filepath'])
    target_date_index = df.loc[df['timestamp'] == params['date']].index[0]
    test_df = df.iloc[target_date_index-params['n_steps']:target_date_index, :]
    test_df['timestamp'] = pd.to_datetime(df['timestamp'])
    test_df['timestamp'] = test_df['timestamp'].apply(lambda x : x + timedelta(hours=8,minutes=00))                                               
    test_df.index = test_df['timestamp']
    test_df = test_df.drop(['timestamp'], axis=1)
    return test_df

def forecast_results(params, model, raw_seq_test):
    _no_days_predict = params['_no_days_predict']
    _no_past_days = params['_no_past_days']
    
    x_input = raw_seq_test[-_no_past_days:]
    end_date_for_existing_data = raw_seq_test.index[-1]
    date_list = []
    for i in range(1,_no_days_predict+1):
        start_date = end_date_for_existing_data + timedelta(days=1)
        end_date_for_existing_data = start_date
        date_list.append(start_date)
    
    if(_no_days_predict == 1):
        #Prediction for a single day, based on last 30 days data
        actual_sequence = np.array([x_input[i] for i in range(x_input.shape[0])])
        actual_sequence_reshaped = actual_sequence.reshape((1, params['n_steps'] , params['n_features']))
        yhat_day_1 = model.predict(actual_sequence_reshaped, verbose=0)
        return [yhat_day_1[0][0]], date_list
        
    elif(_no_days_predict == 7):
        temp_input=list(x_input)
        lst_output=[]
        i=0        
        while(i<_no_days_predict):
            if(len(temp_input) > params['n_steps']):
                x_input=np.array(temp_input[1:])
                x_input = x_input.reshape((1, params['n_steps'] , params['n_features']))
                yhat = model.predict(x_input, verbose=0)
                temp_input.append(yhat[0][0])
                temp_input=temp_input[1:]
                lst_output.append(yhat[0][0])
                i=i+1
            else:
                x_input = x_input.values.reshape((1, params['n_steps'] , params['n_features']))
                yhat = model.predict(x_input, verbose=0)
                temp_input.append(yhat[0][0])
                lst_output.append(yhat[0][0])
                i=i+1
        return lst_output, date_list

                       
def send_email_for_1_day(params, 
                         date_warning_disk,
                         date_warning_cpu):

    gmail_user = params['gmail_user']
    gmail_password = params['gmail_password']
    to_ = params['to_']
    disk_size = params['disk_size']
    cpu_size = params['cpu_size']
    threshold_cpu = params['threshold_cpu']
    threshold_disk = params['threshold_disk']
    
    cpu_left = round(list(date_warning_cpu.values())[0],2)
    disk_left = round(list(date_warning_disk.values())[0],2)
    disk_need_to_free = round(((threshold_disk/100) * disk_size) - disk_left,2) #
    cpu_need_to_free = round(threshold_cpu - cpu_left,2)
    
    
    
    sent_from = gmail_user
    to = to_
    subject = "Resource Exhausted Notifier"
    
    if(cpu_left > threshold_cpu and disk_left > ((threshold_disk/100) * disk_size)):
        body = ""
    elif(cpu_left > threshold_cpu and disk_left < ((threshold_disk/100) * disk_size)):
        body = """You won't have sufficient disk space to run the critical batch job at 8:00 PM today. {} GB disk space is expected to be free. Please free up atleast {} GB disk resources before proceeding further""".format(disk_left, disk_need_to_free)
    elif(cpu_left < threshold_cpu and disk_left > ((threshold_disk/100) * disk_size)):
        body = """You won't have sufficient cpu resources to run the critical batch job at 8:00 PM today. {} % cpu is expected to be free. Please free up another {} % CPU resources before proceeding further""".format(cpu_left, cpu_need_to_free)
    elif(cpu_left < threshold_cpu and disk_left < ((threshold_disk/100) * disk_size)):
        body = """You won't have sufficient cpu and disk resources to run the critical batch job at 8:00 PM today. {} GB disk space & {} % cpu is expected to be free. Please free up atleast {} GB disk resources and {} % CPU resources before proceeding further""".format(disk_left, cpu_left, disk_need_to_free, cpu_need_to_free)
        
    email_text = 'Subject: {}\n\n{}'.format(subject, body)

    if(body==""):
        print("You can run the critical job at 8:00 PM today, without expecting any trouble")
    else:
        try:
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.ehlo()
            server.login(gmail_user, gmail_password)
            server.sendmail(sent_from, to, email_text)
            server.close()
    
            print('User Has Been Notified Over Email About A Possible Critical Job Failure!')
        except:
            print('Something went wrong in SMTP_SSL protocol.')
        
# def send_email_for_7_day(params,
#                          date_warning_disk,
#                          date_warning_cpu):
    
#     gmail_user = params['gmail_user']
#     gmail_password = params['gmail_password']
#     to_ = params['to_']

#     sent_from = gmail_user
#     to = to_
#     subject = "Resource Exhausted Notifier"
    
#     dates_list_disk = list(date_warning_disk.keys())
#     dates_list_disk = [str(i.day )+ "-" + str(i.month) + "-" + str(i.year) for i in dates_list_disk]
#     disk_info = list(date_warning_disk.values())
#     disk_left_list = [disk_info[i][0] for i in range(len(disk_info))]
#     disk_need_to_free_list = [disk_info[i][1] for i in range(len(disk_info))]
        
#     dates_list_cpu = list(date_warning_cpu.keys())
#     dates_list_cpu = [str(i.day )+ "-" + str(i.month) + "-" + str(i.year) for i in dates_list_cpu]
    
    
#     if(len(list(date_warning_disk.keys())) != 0 and len(list(date_warning_cpu.keys())) == 0):
#         body = """This is to inform you that your system resources are predicted to be exhausted on the following dates at 5:30 PM - {}. 
#                           {} GBs disk space is expected to be free on the respective dates. 
#                           Please make sure to free atleast {} GBs for the respective dates before proceeding further""".format(dates_list_disk, 
#                           disk_left_list, disk_need_to_free_list)
#     elif(len(list(date_warning_disk.keys())) == 0 and len(list(date_warning_cpu.keys())) != 0):
#         body = """This is to inform you that your system cpu resources are predicted to be exhausted beyond 30% on the following dates at 5:30 PM - {}. 
#         Please make sure to free up some system cpu resources in the respective dates.""".format(dates_list_cpu)
        
#     elif(len(list(date_warning_disk.keys())) != 0 and len(list(date_warning_cpu.keys())) != 0):
#         body1 = """This is to inform you that your system resources are predicted to be exhausted on the following dates at 5:30 PM - {}. 
#                           {} GBs disk space is expected to be free on the respective dates. 
#                           Please make sure to free atleast {} GBs for the respective dates before proceeding further""".format(dates_list_disk, 
#                           disk_left_list, disk_need_to_free_list)
#         body2 = """This is to inform you that your system cpu resources are predicted to be exhausted beyond 30% on the following dates at 5:30 PM - {}. 
#         Please make sure to free up some system cpu resources in the respective dates.""".format(dates_list_cpu)  
        
#         body = body1 + " " + body2
    
#     email_text = 'Subject: {}\n\n{}'.format(subject, body)
    
#     try:
#         server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
#         server.ehlo()
#         server.login(gmail_user, gmail_password)
#         server.sendmail(sent_from, to, email_text)
#         server.close()
    
#         print('User Notified!')
#     except:
#         print('Something went wrong...')


def predict_and_send_email(params):
    test_df = load_data(params)
    raw_seq_test_cpu = test_df['cpu']
    raw_seq_test_disk = test_df['disk']
    
    cpu_model = load_model(params['model_filepath_cpu'])
    disk_model = load_model(params['model_filepath_disk']) 
    
    predictions_cpu, time_cpu = forecast_results(params, cpu_model, raw_seq_test_cpu)
    predictions_disk, time_disk = forecast_results(params, disk_model, raw_seq_test_disk)
    
    predictions_cpu = [i if i<100 else 100.00 for i in predictions_cpu]
    predictions_disk = [i if i<500 else 500.00 for i in predictions_disk]
    
    disk_size = params['disk_size']
    cpu_size = params['cpu_size']
    
    disk_available = {time_disk[i]: (disk_size-predictions_disk[i]) for i in range(len(predictions_disk))}
    cpu_available = {time_cpu[i]: (cpu_size-predictions_cpu[i]) for i in range(len(predictions_cpu))}
    
    threshold_disk = params['threshold_disk']
    threshold_cpu = params['threshold_cpu']
    date_warning_cpu = dict()
    date_warning_disk = dict()
    
    for k,v in disk_available.items():
        disk_left = v
        if(disk_left < ((threshold_disk/100) * disk_size)):
            disk_need_to_free = ((threshold_disk/100) * disk_size) - disk_left
        else:
            disk_need_to_free = 0
        
        disk_left = round(disk_left,2)
        disk_need_to_free = round(disk_need_to_free,2)
        date_warning_disk[k] = disk_left
            
    for k,v in cpu_available.items():
        cpu_left = v
        date_warning_cpu[k] = cpu_left
        
    if(params['_no_days_predict'] == 1):
        print()
        print("Forecast for {} 8:00 PM".format(params['date']))
        print("DISK AVAILABLE: {} GB".format(list(date_warning_disk.values())[0]))
        print("CPU AVAILABLE: {} %".format(list(date_warning_cpu.values())[0]))
        print()
        
        send_email_for_1_day(params,
                             date_warning_disk,
                             date_warning_cpu)
        
    
    elif(params['_no_days_predict'] == 7):
        dates = [time_cpu[i].date().strftime('%Y-%m-%d') for i in range(len(time_cpu))]
        
        for i in range(len(dates)):
            print("Forecast for {} 8:00 PM".format(dates[i]))
            print("DISK AVAILABLE: {} GB".format(list(disk_available.values())[i]))
            print("CPU AVAILABLE: {} %".format(list(cpu_available.values())[i]))
            print()
        
        # send_email_for_7_day(params,
        #                      date_warning_disk,
        #                      date_warning_cpu)


if __name__ == '__main__':
    """
    Start the pipeline.
    Set the parameters.
    """
    
    parser = argparse.ArgumentParser(description='this script will forecast resource utilizations')
    parser.add_argument('--n_steps', type=int, default=30, help="timesteps, number of past days the models looks into")
    parser.add_argument('--n_features', type=int, default=1, help="number of features of the prediction variable")
    parser.add_argument('--model_filepath_disk', type=str, default="saved_models_disk/bidirectional.h5", help="location of the final disk model")
    parser.add_argument('--model_filepath_cpu', type=str, default="saved_models_cpu/vanila_3.h5", help="location of the final cpu model")
    parser.add_argument('--date', type=str, default='2020-12-28', help="enter the date to provide forecast for")
    parser.add_argument('--df_filepath', type=str, default='Simulated_Data_For_Testing.csv', help="location of the test data series")
    parser.add_argument('--_no_days_predict', type=str, default=1, help="number of days to forecast")
    parser.add_argument('--disk_size', type=int, default=500, help="total size of disk in GB")
    parser.add_argument('--cpu_size', type=int, default=100, help="total cpu bandwidth")
    parser.add_argument('--threshold_disk', type=int, default=1, help="disk limit threshold in % to sound warning alert")
    parser.add_argument('--threshold_cpu', type=int, default=30, help="cpu limit threshold in % to sound warning alert")

    args = parser.parse_args()

    params = dict()
    params['n_steps'] = args.n_steps
    params['n_features'] = args.n_features
    params['model_filepath_disk'] = args.model_filepath_disk
    params['model_filepath_cpu'] = args.model_filepath_cpu
    params['date'] = args.date
    params['df_filepath'] = args.df_filepath
    params['_no_days_predict'] = args._no_days_predict
    params['_no_past_days'] = params['n_steps']
    params['disk_size'] = args.disk_size
    params['cpu_size'] = args.cpu_size
    params['threshold_disk'] = args.threshold_disk
    params['threshold_cpu'] = args.threshold_cpu
    params['gmail_user'] = gmail_user
    params['gmail_password'] = gmail_password
    params['to_'] = to_
    
    predict_and_send_email(params)